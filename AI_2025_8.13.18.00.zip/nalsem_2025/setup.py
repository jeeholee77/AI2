from setuptools import setup, find_packages
from glob import glob

package_name = 'nalsem_2025'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(include=[package_name, f"{package_name}.*"]),
    data_files=[
        ('share/ament_index/resource_index/packages', [f'resource/{package_name}']),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Jetson',
    maintainer_email='jeehonae@naver.com',
    description='Bringup package for the autonomous boat project (NALSEM 2025)',
    license='MIT',
    entry_points={
        'console_scripts': [
            'motor_operating = nalsem_2025.drive_mode1.motor_operating:main',
            'waypoint_node = nalsem_2025.drive_mode1.waypoint_node:main',
            'waypoint_heading_node = nalsem_2025.drive_mode1.waypoint_heading_node:main',
            'gps_averaging_node = nalsem_2025.waypoint.gps_averaging_node:main',
            'yolo_camera_node = nalsem_2025.drive_mode1.yolo_camera_node:main',
            'lidar_heading_filter_node = nalsem_2025.drive_mode1.lidar_heading_filter_node:main',
            'navigation_decision_node = nalsem_2025.drive_mode1.navigation_decision_node:main',
            'control_panel_node = nalsem_2025.control.control_panel_node:main',
            'visualization_node = nalsem_2025.control.visualization_node:main',
        ],
    },
)
