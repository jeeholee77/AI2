# bringup.launch.py  — Sensors only (LiDAR, GPS, IMU)

import os
from launch import LaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import IncludeLaunchDescription
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # LiDAR (SLLIDAR S3)
    lidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('sllidar_ros2'),
                'launch',
                'sllidar_s3_launch.py'
            )
        )
    )

    # GPS (u-blox)
    gps_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('ublox_gps'),
                'launch',
                'ublox_gps_node_base-launch.py'
            )
        )
    )

    # IMU (iAHRS)
    imu_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('iahrs_ros2_driver'),
                'launch',
                'iahrs_driver.launch.py'
            )
        )
    )

    return LaunchDescription([
        lidar_launch,
        gps_launch,
        imu_launch,
    ])
