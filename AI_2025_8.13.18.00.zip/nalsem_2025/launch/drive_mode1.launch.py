# drive_mode1.launch.py — Navigation stack only (no sensors)

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    motor_node = Node(
        package='nalsem_2025',
        executable='motor_operating',
        name='motor_operating',
        output='screen',
        sigterm_timeout='1.0',
    )

    waypoint_node = Node(
        package='nalsem_2025',
        executable='waypoint_node',
        name='waypoint_node',
        output='screen',
    )

    yolo_camera_node = Node(
        package='nalsem_2025',
        executable='yolo_camera_node',
        name='yolo_camera_node',
        output='screen',
    )

    lidar_filter_node = Node(
        package='nalsem_2025',
        executable='lidar_heading_filter_node',
        name='lidar_heading_filter_node',
        output='screen',
    )

    waypoint_heading_node = Node(
        package='nalsem_2025',
        executable='waypoint_heading_node',
        name='waypoint_heading_node',
        output='screen',
    )

    navigation_decision_node = Node(
        package='nalsem_2025',
        executable='navigation_decision_node',  # PID 쓰려면 'navigation_decision_node_pid'
        name='navigation_decision_node',
        output='screen',
    )

    return LaunchDescription([
        motor_node,
        waypoint_node,
        yolo_camera_node,
        lidar_filter_node,
        waypoint_heading_node,
        navigation_decision_node,
    ])
