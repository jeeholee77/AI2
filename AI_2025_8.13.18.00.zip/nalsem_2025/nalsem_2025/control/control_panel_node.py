#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32, Int32MultiArray
from sensor_msgs.msg import NavSatFix
import sys
import threading
import time

class ControlPanelNode(Node):
    def __init__(self):
        super().__init__('control_panel_node')

        # 상태 변수 초기화
        self.current_position = ("-", "-")
        self.goal_latlon = ("-", "-")
        self.status = [-1, -1]
        self.heading = -1
        self.safe_heading_list = []
        self.final_heading = -1
        self.motor_cmd = []

        # 카메라 상태 (색 제거)
        self.camera_heading = -1

        # 마지막 수신 시간 기록용
        self.last_received = {
            'fix': 0,
            'goal': 0,
            'status': 0,
            'heading': 0,
            'safe': 0,
            'final': 0,
            'motor': 0,
            'camera': 0,
        }

        # === 토픽 구독 ===
        self.create_subscription(NavSatFix, '/fix', self.fix_callback, 10)
        self.create_subscription(NavSatFix, '/waypoint/goal', self.goal_callback, 10)
        self.create_subscription(Int32MultiArray, '/waypoint/status', self.status_callback, 10)
        self.create_subscription(Int32, '/waypoint/heading', self.heading_callback, 10)
        self.create_subscription(Int32MultiArray, '/safe_heading', self.safe_heading_callback, 10)
        self.create_subscription(Int32, '/final_heading', self.final_heading_callback, 10)
        self.create_subscription(Int32MultiArray, '/motor_cmd', self.motor_cmd_callback, 10)

        # 카메라 헤딩만 구독
        self.create_subscription(Int32, '/camera_heading', self.camera_heading_callback, 10)

        # 실시간 출력 쓰레드 실행
        self.print_thread = threading.Thread(target=self.display_loop, daemon=True)
        self.print_thread.start()

    # === 콜백 ===
    def fix_callback(self, msg):
        self.current_position = (f"{msg.latitude:.6f}", f"{msg.longitude:.6f}")
        self.last_received['fix'] = time.monotonic()

    def goal_callback(self, msg):
        self.goal_latlon = (f"{msg.latitude:.6f}", f"{msg.longitude:.6f}")
        self.last_received['goal'] = time.monotonic()

    def status_callback(self, msg):
        self.status = msg.data
        self.last_received['status'] = time.monotonic()

    def heading_callback(self, msg):
        self.heading = msg.data
        self.last_received['heading'] = time.monotonic()

    def safe_heading_callback(self, msg):
        self.safe_heading_list = msg.data
        self.last_received['safe'] = time.monotonic()

    def final_heading_callback(self, msg):
        self.final_heading = msg.data
        self.last_received['final'] = time.monotonic()

    def motor_cmd_callback(self, msg):
        self.motor_cmd = msg.data
        self.last_received['motor'] = time.monotonic()

    def camera_heading_callback(self, msg):
        self.camera_heading = int(msg.data)
        self.last_received['camera'] = time.monotonic()

    # === 출력 루프 ===
    def display_loop(self):
        while rclpy.ok():
            now = time.monotonic()
            print("\033[2J\033[H", end="")  # clear + cursor home

            print("📡 Current Position  : ", end="")
            if now - self.last_received['fix'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.current_position[0]}, {self.current_position[1]}")

            print("────────────────────────────────────────────")

            print("📍 Current Goal      : ", end="")
            if now - self.last_received['goal'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.goal_latlon[0]}, {self.goal_latlon[1]}")

            print("🎯 Goal Status       : ", end="")
            if now - self.last_received['status'] > 5:
                print("⚠️ 미수신")
            else:
                goal_number = self.status[0]   # 1,2,3,...
                status_code = self.status[1]   # 0=주행중, 1=도달

                # ✅ 3번 주행 이후 도달 시 '미션 컴플릿'
                if goal_number == 3 and status_code == 1:
                    print("미션 컴플릿 ✅")
                else:
                    if goal_number <= 0:
                        print("정보 없음")
                    else:
                        if status_code == 0:
                            print(f"{goal_number}번 주행중")
                        else:
                            # (선택) 중간 웨이포인트 도달 메시지
                            print(f"{goal_number}번 도달")

            print()

            print("🧭 Waypoint Heading  : ", end="")
            if now - self.last_received['heading'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.heading}°")

            print("🛡️ Safe Headings     : ", end="")
            if now - self.last_received['safe'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.safe_heading_list}")
            print()

            print("✅ Final Heading     : ", end="")
            if now - self.last_received['final'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.final_heading}°")

            print("⚙️ Motor PWM Command : ", end="")
            if now - self.last_received['motor'] > 5:
                print("⚠️ 미수신")
            else:
                print(f"{self.motor_cmd}")

            print("────────────────────────────────────────────")

            # === 카메라: 헤딩 값만 표기 ===
            print("🎥 Camera Detection  : ", end="")
            if now - self.last_received['camera'] <= 5:
                print(f"인식, heading={self.camera_heading}°")
            else:
                print("미검출")

            sys.stdout.flush()
            time.sleep(0.5)

# === 메인 ===
def main(args=None):
    rclpy.init(args=args)
    node = ControlPanelNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
