#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Int32, Int32MultiArray
from cv_bridge import CvBridge
import cv2
import math
import numpy as np

def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v

class VisualizationNode(Node):
    def __init__(self):
        super().__init__('visualization_node')

        self.bridge = CvBridge()
        self.image = None
        self.safe_heading_list = []
        self.final_heading = None

        # 실제 센서 가시 범위(소스 각도)
        self.src_lo = 55
        self.src_hi = 125
        self.src_range = self.src_hi - self.src_lo  # 70°

        # 디스플레이 각도: 0~180° 전체 사용
        self.disp_lo = 0
        self.disp_hi = 180
        self.disp_range = self.disp_hi - self.disp_lo  # 180°

        # 스타일 파라미터
        self.r_ratio = 0.48                 # 반지름: 화면 높이 비율
        self.safe_alpha = 0.35              # 안전 영역 파스텔 투명도
        self.safe_color = (120, 255, 120)   # 파스텔 그린 (BGR)
        self.arrow_color = (255, 0, 0)
        self.arrow_tip_ratio = 0.85         # 화살표 길이(반경 비율)

        # 범위 밖 인디케이터(삼각형)
        self.indicator_color = (255, 255, 255)
        self.indicator_tip_ratio = 0.82
        self.indicator_base_ratio = 0.92
        self.indicator_half_width = 10

        # 구독
        self.create_subscription(Image, '/camera/image_raw', self.image_callback, 10)
        self.create_subscription(Int32MultiArray, '/safe_heading', self.safe_callback, 10)
        self.create_subscription(Int32, '/final_heading', self.heading_callback, 10)

        # 화면 갱신 (20 fps)
        self.timer = self.create_timer(0.05, self.display_frame)

    # ── 콜백 ─────────────────────────────────────
    def image_callback(self, msg):
        self.image = self.bridge.imgmsg_to_cv2(msg, "bgr8")

    def safe_callback(self, msg):
        self.safe_heading_list = list(msg.data) if msg.data is not None else []

    def heading_callback(self, msg):
        self.final_heading = int(msg.data)

    # ── 유틸 ─────────────────────────────────────
    def angle_to_point(self, a_deg, cx, cy, r):
        # 디스플레이 각도 기준: 0°=오른쪽, 90°=위, 180°=왼쪽
        rad = math.radians(a_deg)
        x = int(round(cx + r * math.cos(rad)))
        y = int(round(cy - r * math.sin(rad)))  # 화면 y는 아래로 증가 → -sin
        return (x, y)

    def map_src_to_disp(self, a_src):
        # 실제 55~125° → 화면 0~180° 선형 리매핑
        return (a_src - self.src_lo) * self.disp_range / self.src_range + self.disp_lo

    def merge_ranges(self, vals, lo, hi):
        s = sorted(set([v for v in vals if lo <= v <= hi]))
        if not s:
            return []
        ranges, start = [], s[0]
        prev = start
        for a in s[1:]:
            if a == prev + 1:
                prev = a
            else:
                ranges.append((start, prev))
                start = prev = a
        ranges.append((start, prev))
        return ranges  # [(a0, a1), ...]

    # ── 그리기 ───────────────────────────────────
    def draw_guides(self, frame, cx, cy, r):
        # 반원 전체(0~180°) 가이드 + 중앙선
        cv2.ellipse(frame, (cx, cy), (r, r), 0, 0, 180, (200, 200, 200), 1)
        cv2.line(frame, (cx, cy), self.angle_to_point(90, cx, cy, r), (200, 200, 200), 1)
        # 좌/우 경계선
        cv2.line(frame, (cx, cy), self.angle_to_point(0, cx, cy, r), (180, 180, 180), 1)
        cv2.line(frame, (cx, cy), self.angle_to_point(180, cx, cy, r), (180, 180, 180), 1)

    def draw_safe_sectors(self, frame, ranges_src, cx, cy, r):
        if not ranges_src:
            return frame
        overlay = frame.copy()
        for a0, a1 in ranges_src:
            # 소스 각도 구간 → 디스플레이 각도 구간
            d0 = self.map_src_to_disp(a0)
            d1 = self.map_src_to_disp(a1)
            pts = [(cx, cy)]
            for a in range(int(round(min(d0, d1))), int(round(max(d0, d1))) + 1):
                pts.append(self.angle_to_point(a, cx, cy, r))
            cv2.fillPoly(overlay, [np.array(pts, dtype=np.int32)], self.safe_color)
        return cv2.addWeighted(overlay, self.safe_alpha, frame, 1 - self.safe_alpha, 0)

    def draw_edge_indicator(self, frame, a_disp, cx, cy, r):
        # a_disp(0 또는 180) 방향으로 안쪽을 향하는 삼각형
        rad = math.radians(a_disp)
        vx, vy = math.cos(rad), -math.sin(rad)          # 방향 벡터
        px, py = (math.sin(rad), math.cos(rad))         # 수직 벡터(+90°)
        tip_r = int(r * self.indicator_tip_ratio)
        base_r = int(r * self.indicator_base_ratio)
        hw = self.indicator_half_width

        tip = (int(cx + vx * tip_r),  int(cy + vy * tip_r))
        base_c = (int(cx + vx * base_r), int(cy + vy * base_r))
        b1 = (int(base_c[0] + px * hw), int(base_c[1] + py * hw))
        b2 = (int(base_c[0] - px * hw), int(base_c[1] - py * hw))

        tri = np.array([tip, b1, b2], dtype=np.int32)
        cv2.fillPoly(frame, [tri], self.indicator_color)

    # ── 메인 렌더 ────────────────────────────────
    def display_frame(self):
        if self.image is None:
            return

        frame = self.image.copy()
        h, w, _ = frame.shape

        cx, cy = w // 2, h - 1
        r = int(h * self.r_ratio)

        # 1) 가이드(0~180 반원 전체)
        self.draw_guides(frame, cx, cy, r)

        # 2) 안전 구간 파스텔 채움 (소스 55~125만 사용 → 디스플레이로 매핑)
        ranges_src = self.merge_ranges(self.safe_heading_list, self.src_lo, self.src_hi)
        frame = self.draw_safe_sectors(frame, ranges_src, cx, cy, r)

        # 3) 파이널 헤딩
        if self.final_heading is not None:
            fh = self.final_heading
            if self.src_lo <= fh <= self.src_hi:
                # 범위 안: 디스플레이 각도로 리매핑 후 화살표
                a_disp = self.map_src_to_disp(fh)
                tip = self.angle_to_point(a_disp, cx, cy, int(r * self.arrow_tip_ratio))
                cv2.arrowedLine(frame, (cx, cy), tip, self.arrow_color, 3, tipLength=0.12)
            else:
                # 범위 밖: 경계 인디케이터 (오른쪽=0°, 왼쪽=180°)
                self.draw_edge_indicator(frame, 0 if fh < self.src_lo else 180, cx, cy, r)

        # 4) 표시
        cv2.imshow("Camera HUD", frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = VisualizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
