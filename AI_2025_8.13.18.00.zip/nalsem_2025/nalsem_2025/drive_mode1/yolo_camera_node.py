#!/usr/bin/env python3
import os
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import Int32

# ▶ 사진(실내 형광등, 유광 반사) 기반 튜닝 값
#   H: 0~179, S/V: 0~255
HSV_RANGES = {
    # 빨강은 원형이므로 두 구간
    "red1":  ((0,   95, 120), (10, 255, 255)),
    "red2":  ((170, 95, 120), (179,255, 255)),
    # 초록: 반사 억제 위해 S/V 하한을 살짝 올림
    "green": ((45, 100,  80), (85, 255, 255)),
    # 파랑: 실물 기준 중심대가 H≈102 부근, 저포화/저밝기 배경 제거
    "blue":  ((95, 115, 130), (130,255,255)),
}

class CameraColorHeadingDirect(Node):
    def __init__(self):
        super().__init__('camera_color_heading_direct')

        # ▶ 파라미터
        self.declare_parameter('device', '/dev/camera')      # 또는 /dev/video0
        self.declare_parameter('width', 640)
        self.declare_parameter('height', 480)
        self.declare_parameter('fps', 30.0)
        self.declare_parameter('target_color', 'green')        # red | green | blue
        self.declare_parameter('publish_topic', '/camera_heading')
        self.declare_parameter('image_topic', '/camera/image_raw')
        self.declare_parameter('debug_mask_topic', '/camera/mask')
        self.declare_parameter('min_area', 300)              # 노이즈 제거 임계 면적(px)

        self.dev = self.get_parameter('device').value
        self.W = int(self.get_parameter('width').value)
        self.H = int(self.get_parameter('height').value)
        self.FPS = float(self.get_parameter('fps').value)
        self.target_color = self.get_parameter('target_color').value
        self.pub_topic = self.get_parameter('publish_topic').value
        self.image_topic = self.get_parameter('image_topic').value
        self.mask_topic = self.get_parameter('debug_mask_topic').value
        self.min_area = int(self.get_parameter('min_area').value)

        # ▶ 퍼블리셔
        self.pub_heading = self.create_publisher(Int32, self.pub_topic, 10)
        self.pub_image = self.create_publisher(Image, self.image_topic, 10)
        self.pub_mask = self.create_publisher(Image, self.mask_topic, 10)
        self.bridge = CvBridge()

        # ▶ 카메라 오픈
        if not os.path.exists(self.dev):
            raise FileNotFoundError(f'Camera device not found: {self.dev}')
        self.cap = cv2.VideoCapture(self.dev, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.W)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.H)
        self.cap.set(cv2.CAP_PROP_FPS, self.FPS)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

        if not self.cap.isOpened():
            raise RuntimeError(f'Failed to open camera: {self.dev}')

        actual_w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        actual_fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.get_logger().info(f'🎥 Opened {self.dev} @ {actual_w}x{actual_h} {actual_fps:.1f}fps')

        self.timer = self.create_timer(max(1.0 / max(1.0, self.FPS), 0.001), self.loop)

    # 55~125 매핑
    def map_to_55_125(self, cx, width):
        return int(round(55 + (cx / float(width)) * (125 - 55)))

    # 색 마스크 생성
    def get_mask(self, hsv):
        if self.target_color == 'red':
            m1 = cv2.inRange(hsv, np.array(HSV_RANGES['red1'][0]), np.array(HSV_RANGES['red1'][1]))
            m2 = cv2.inRange(hsv, np.array(HSV_RANGES['red2'][0]), np.array(HSV_RANGES['red2'][1]))
            mask = cv2.bitwise_or(m1, m2)
        else:
            lower, upper = HSV_RANGES[self.target_color]
            mask = cv2.inRange(hsv, np.array(lower), np.array(upper))
        # 노이즈 제거
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        return mask

    def loop(self):
        ok, frame = self.cap.read()
        if not ok or frame is None:
            self.get_logger().warn('프레임 읽기 실패')
            return

        h, w = frame.shape[:2]
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = self.get_mask(hsv)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        heading_val = None
        shape_name = None

        if contours:
            c = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(c)
            if area > self.min_area:
                # 중심, heading 계산
                x, y, ww, hh = cv2.boundingRect(c)
                cx = x + ww // 2
                heading_val = self.map_to_55_125(cx, w)
                heading_val = 180 - heading_val
                heading_val = max(55, min(125, heading_val))

                # 모양 판별
                peri = cv2.arcLength(c, True)
                approx = cv2.approxPolyDP(c, 0.04 * peri, True)
                vertices = len(approx)

                if vertices == 3:
                    shape_name = "Triangle"
                elif vertices > 5:
                    circularity = 4 * np.pi * area / (peri * peri + 1e-5)
                    if circularity > 0.80:
                        shape_name = "Circle"
                    else:
                        shape_name = f"Polygon({vertices})"
                else:
                    shape_name = f"Polygon({vertices})"

                # 디버그 표시
                cv2.drawContours(frame, [approx], -1, (0, 255, 255), 2)
                cv2.circle(frame, (cx, y + hh // 2), 5, (0, 255, 255), -1)

        # 중앙선
        cv2.line(frame, (w // 2, 0), (w // 2, h), (255, 255, 255), 1)

        # 퍼블리시 + 로그
        if heading_val is not None:
            msg = Int32()
            msg.data = heading_val
            self.pub_heading.publish(msg)
            if shape_name:
                self.get_logger().info(f"{self.target_color} / {shape_name} → heading(inv)={heading_val}")
            else:
                self.get_logger().info(f"{self.target_color} / Unknown shape → heading(inv)={heading_val}")
        else:
            self.get_logger().info(f"{self.target_color} 미검출 → 퍼블리시 없음")

        # 이미지/마스크 퍼블리시
        if self.pub_image.get_subscription_count() > 0:
            self.pub_image.publish(self.bridge.cv2_to_imgmsg(frame, encoding='bgr8'))
        if self.pub_mask.get_subscription_count() > 0:
            self.pub_mask.publish(self.bridge.cv2_to_imgmsg(mask, encoding='mono8'))

    def destroy_node(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()
        super().destroy_node()

def main():
    rclpy.init()
    node = CameraColorHeadingDirect()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()