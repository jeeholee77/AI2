#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from std_msgs.msg import Int32, Int32MultiArray
import numpy as np

def clamp(v, lo, hi):
    return int(min(max(v, lo), hi))

def find_nearest(array, value):
    if not array:
        return None
    arr = np.asarray(array, dtype=np.int32)
    idx = (np.abs(arr - value)).argmin()
    return int(arr[idx])

class NavigationDecisionNode(Node):
    def __init__(self):
        super().__init__('navigation_decision_node')

        # ▶ 파라미터
        self.declare_parameter('camera_mode_secs', 1.0)
        self.declare_parameter('heading_min', 0)
        self.declare_parameter('heading_max', 180)

        self.camera_mode_duration = Duration(seconds=float(self.get_parameter('camera_mode_secs').value))
        self.hmin = int(self.get_parameter('heading_min').value)
        self.hmax = int(self.get_parameter('heading_max').value)

        # ▶ 상태
        self.camera_heading = 90
        self.b_heading = 90
        self.safe_heading_list = []
        self.last_camera_time = self.get_clock().now()

        # ▶ 퍼블리셔
        self.pwm_pub = self.create_publisher(Int32MultiArray, '/motor_cmd', 10)
        self.final_heading_pub = self.create_publisher(Int32, '/final_heading', 10)

        # ▶ 서브스크립션
        self.create_subscription(Int32, '/waypoint/heading', self.heading_callback, 10)
        self.create_subscription(Int32MultiArray, '/safe_heading', self.safe_callback, 10)
        self.create_subscription(Int32, '/camera_heading', self.camera_callback, 10)

        # ▶ 제어 루프
        self.create_timer(0.1, self.control_loop)

        self.get_logger().info('✅ navigation_decision_node up')

    # ----------------- 콜백 -----------------
    def safe_callback(self, msg):
        self.safe_heading_list = [clamp(h, self.hmin, self.hmax) for h in msg.data]

    def heading_callback(self, msg):
        self.b_heading = clamp(int(msg.data), self.hmin, self.hmax)

    def camera_callback(self, msg):
        self.camera_heading = clamp(int(msg.data), self.hmin, self.hmax)
        self.last_camera_time = self.get_clock().now()
        self.get_logger().info(f'📸 camera_heading={self.camera_heading}')

    # ----------------- 메인 루프 -----------------
    def control_loop(self):
        now = self.get_clock().now()
        in_camera_mode = (now - self.last_camera_time) < self.camera_mode_duration

        if in_camera_mode:
            final_heading = self.camera_heading
        else:
            final_heading = self.select_heading(self.b_heading, self.safe_heading_list)

        self.publish_final_heading(final_heading)
        self.motor_control(final_heading)

    # ----------------- 의사결정 -----------------
    def select_heading(self, desired, safe_list):
        desired = clamp(desired, self.hmin, self.hmax)

        # ✅ 안전 리스트가 비었으면 웨이포인트 헤딩으로 진행
        if not safe_list:
            return desired

        if desired in safe_list:
            return desired

        nearest = find_nearest(safe_list, desired)
        if nearest is not None:
            return nearest

        # 방어적 폴백(이론상 도달X)
        return desired

    # ----------------- PWM 매핑 -----------------
    def motor_control(self, heading):
        h = clamp(int(heading), self.hmin, self.hmax)
        pwm = Int32MultiArray()

        if h > 160:
            pwm.data = [1650, 1365]
        elif 140 < h <= 160:
            pwm.data = [1650, 1365]
        elif 105 < h <= 140:
            pwm.data = [1600, 1410]
        elif 75  < h <= 105:
            pwm.data = [1420, 1420]   # 직진
        elif 40  < h <= 75:
            pwm.data = [1410, 1600]
        elif 20  < h <= 40:
            pwm.data = [1365, 1650]
        else:  # h <= 20
            pwm.data = [1365, 1650]
    

        self.pwm_pub.publish(pwm)

    def publish_final_heading(self, heading):
        msg = Int32()
        msg.data = clamp(int(heading), self.hmin, self.hmax)
        self.final_heading_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = NavigationDecisionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
