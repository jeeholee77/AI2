#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import math
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Int32MultiArray

def devide1(array, a, b):
    array[a] = 1
    for i in range(1, b + 1):
        if a - i >= 0:
            array[a - i] = 1
        if a + i <= 180:
            array[a + i] = 1
    return array

class LidarHeadingFilter(Node):
    def __init__(self):
        super().__init__('lidar_heading_filter_node')

        self.declare_parameter("risk_threshold", 55)
        self.declare_parameter("effect_angle", 20)

        self.risk_threshold = self.get_parameter("risk_threshold").value
        self.effect_angle = self.get_parameter("effect_angle").value

        self.subscriber = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)

        self.publisher = self.create_publisher(
            Int32MultiArray,
            '/safe_heading',
            10)

        self.get_logger().info("✅ Lidar Heading Filter Node (MultiArray) Started.")

    def scan_callback(self, data):
        datas_right = np.array(data.ranges[2430:3240])
        datas_left = np.array(data.ranges[0:810])
        datas = np.concatenate((datas_right, datas_left))

        risk1 = np.zeros(181)
        risk2 = np.zeros(181)
        risk3 = np.zeros(181)
        risk4 = np.zeros(181)
        risk5 = np.zeros(181)  # 마스킹용: 0이면 통과 가능

        for i in range(len(datas)):
            length = datas[i]
            if length != 0 and not math.isinf(length):
                y = round(i * 180 / len(datas))
                risk1[y] += length
                risk2[y] += 1

        for j in range(181):
            if risk2[j] > 0:
                risk3[j] = risk1[j] / risk2[j]

        for i in range(181):
            if risk3[i] > 0:
                risk4[i] = 135.72 * math.exp(-0.6109 * risk3[i])

        for k in range(181):
            if risk4[k] >= self.risk_threshold:
                devide1(risk5, k, self.effect_angle)

        allow_list = np.where(risk5 == 0)[0].tolist()

        msg = Int32MultiArray()
        msg.data = allow_list
        self.publisher.publish(msg)

      

def main(args=None):
    rclpy.init(args=args)
    node = LidarHeadingFilter()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()