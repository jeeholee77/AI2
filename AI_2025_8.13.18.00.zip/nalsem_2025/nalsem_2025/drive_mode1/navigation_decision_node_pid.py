#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from std_msgs.msg import Int32, Int32MultiArray
import numpy as np
import time

def clamp(v, lo, hi):
    return int(min(max(v, lo), hi))

def find_nearest(array, value):
    if not array:
        return None
    arr = np.asarray(array, dtype=np.int32)
    idx = (np.abs(arr - value)).argmin()
    return int(arr[idx])

class NavigationDecisionNode(Node):
    def __init__(self):
        super().__init__('navigation_decision_node')

        # ▶ 파라미터 선언
        self.declare_parameter('camera_mode_secs', 1.0)
        self.declare_parameter('heading_min', 0)
        self.declare_parameter('heading_max', 180)

        # PD 게인/모터 파라미터
        self.declare_parameter('Kp', 1.5)
        self.declare_parameter('Kd', 0.5)       # Ki는 0(적분 없음)
        self.declare_parameter('target_heading', 90)
        self.declare_parameter('base_pwm', 1450)
        self.declare_parameter('max_output', 200)
        self.declare_parameter('pwm_min', 1200)
        self.declare_parameter('pwm_max', 1700)

        # ▶ 파라미터 로드
        self.camera_mode_duration = Duration(seconds=float(self.get_parameter('camera_mode_secs').value))
        self.hmin = int(self.get_parameter('heading_min').value)
        self.hmax = int(self.get_parameter('heading_max').value)

        self.Kp = float(self.get_parameter('Kp').value)
        self.Kd = float(self.get_parameter('Kd').value)
        self.target_heading = int(self.get_parameter('target_heading').value)
        self.base_pwm = int(self.get_parameter('base_pwm').value)
        self.max_output = float(self.get_parameter('max_output').value)
        self.pwm_min = int(self.get_parameter('pwm_min').value)
        self.pwm_max = int(self.get_parameter('pwm_max').value)

        # ▶ 상태
        self.camera_heading = 90
        self.b_heading = 90
        self.safe_heading_list = []
        self.last_camera_time = self.get_clock().now()

        # PD 내부 상태
        self.prev_error = 0.0
        self.prev_time = time.monotonic()

        # ▶ 퍼블리셔
        self.pwm_pub = self.create_publisher(Int32MultiArray, '/motor_cmd', 10)   # [R, L] 순서
        self.final_heading_pub = self.create_publisher(Int32, '/final_heading', 10)

        # ▶ 서브스크립션
        self.create_subscription(Int32, '/waypoint/heading', self.heading_callback, 10)
        self.create_subscription(Int32MultiArray, '/safe_heading', self.safe_callback, 10)
        self.create_subscription(Int32, '/camera_heading', self.camera_callback, 10)

        # ▶ 제어 루프(10Hz)
        self.create_timer(0.1, self.control_loop)

        self.get_logger().info('✅ navigation_decision_node (PD) up')

    # ----------------- 콜백 -----------------
    def safe_callback(self, msg):
        # 안전 리스트 수신 시 범위 클램프
        self.safe_heading_list = [clamp(h, self.hmin, self.hmax) for h in msg.data]

    def heading_callback(self, msg):
        # 웨이포인트 기반 기본 상대 헤딩
        self.b_heading = clamp(int(msg.data), self.hmin, self.hmax)

    def camera_callback(self, msg):
        # 카메라 헤딩 갱신 및 마지막 수신 시각 기록
        self.camera_heading = clamp(int(msg.data), self.hmin, self.hmax)
        self.last_camera_time = self.get_clock().now()
        self.get_logger().info(f'📸 camera_heading={self.camera_heading}')

    # ----------------- 메인 루프 -----------------
    def control_loop(self):
        now = self.get_clock().now()
        in_camera_mode = (now - self.last_camera_time) < self.camera_mode_duration

        if in_camera_mode:
            final_heading = self.camera_heading
        else:
            final_heading = self.select_heading(self.b_heading, self.safe_heading_list)

        self.publish_final_heading(final_heading)
        self.motor_control(final_heading)

    # ----------------- 의사결정 -----------------
    def select_heading(self, desired, safe_list):
        """
        우선순위:
        1) safe_list 비었으면 웨이포인트 헤딩(desired)으로 진행
        2) desired가 안전이면 그대로 사용
        3) 아니면 안전 리스트에서 가장 가까운 값 선택
        4) 그래도 실패 시에는 desired로 회귀
        """
        desired = clamp(desired, self.hmin, self.hmax)

        # ✅ 변경: 안전 리스트 없으면 90이 아니라 웨이포인트 헤딩(desired) 사용
        if not safe_list:
            return desired

        if desired in safe_list:
            return desired

        nearest = find_nearest(safe_list, desired)
        return nearest if nearest is not None else desired

    # ----------------- PD 제어 -----------------
    def motor_control(self, heading):
        heading = clamp(int(heading), self.hmin, self.hmax)

        # 에러(목표-현재): 목표 90 기준 좌우 편차
        error = float(self.target_heading - heading)

        # 시간차 기반 미분
        now_t = time.monotonic()
        dt = max(1e-3, now_t - self.prev_time)
        d_error = (error - self.prev_error) / dt

        # PD 출력
        P = self.Kp * error
        D = self.Kd * d_error
        output = P + D

        # 상태 업데이트
        self.prev_error = error
        self.prev_time = now_t

        # 출력 제한
        output = float(max(-self.max_output, min(self.max_output, output)))

        # 좌우 PWM 계산 (publish 순서 [R, L])
        left_pwm  = int(self.base_pwm + output)
        right_pwm = int(self.base_pwm - output)

        left_pwm  = clamp(left_pwm,  self.pwm_min, self.pwm_max)
        right_pwm = clamp(right_pwm, self.pwm_min, self.pwm_max)

        pwm_msg = Int32MultiArray()
        pwm_msg.data = [right_pwm, left_pwm]
        self.pwm_pub.publish(pwm_msg)

        self.get_logger().info(
            f"[PD] hdg={heading} err={error:.1f} dt={dt*1000:.0f}ms out={output:.1f} L={left_pwm} R={right_pwm}"
        )

    # ----------------- 퍼블리시 -----------------
    def publish_final_heading(self, heading):
        msg = Int32()
        msg.data = clamp(int(heading), self.hmin, self.hmax)
        self.final_heading_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = NavigationDecisionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
