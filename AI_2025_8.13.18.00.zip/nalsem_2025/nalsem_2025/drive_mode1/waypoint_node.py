#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import Float32
import math

class WaypointNode(Node):
    def __init__(self):
        super().__init__('waypoint_node')

        # 웨이포인트 리스트 (위도, 경도)
        self.waypoints = [
            (35.123456, 129.123456),
            (35.124000, 129.124000),
            (35.125000, 129.125000)
        ]
        self.current_index = 0

        self.sub_gps = self.create_subscription(
            NavSatFix,
            '/fix',
            self.gps_callback,
            10
        )

        self.pub_heading = self.create_publisher(Float32, '/waypoint/heading/test', 10)
        self.pub_distance = self.create_publisher(Float32, '/waypoint/distance', 10)

    def gps_callback(self, msg):
        if self.current_index >= len(self.waypoints):
            return  # 모든 웨이포인트 통과 완료

        current_lat = msg.latitude
        current_lon = msg.longitude
        target_lat, target_lon = self.waypoints[self.current_index]

        distance = self.haversine(current_lat, current_lon, target_lat, target_lon)
        heading = self.calculate_heading(current_lat, current_lon, target_lat, target_lon)

        self.pub_heading.publish(Float32(data=heading))
        self.pub_distance.publish(Float32(data=distance))

        if distance < 5.0:  # 5m 이하이면 다음 웨이포인트로
            self.get_logger().info(f'도달: waypoint {self.current_index}')
            self.current_index += 1

    def haversine(self, lat1, lon1, lat2, lon2):
        R = 6371000  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)

        a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def calculate_heading(self, lat1, lon1, lat2, lon2):
        dLon = math.radians(lon2 - lon1)
        y = math.sin(dLon) * math.cos(math.radians(lat2))
        x = math.cos(math.radians(lat1)) * math.sin(math.radians(lat2)) - \
            math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(dLon)
        heading = math.degrees(math.atan2(y, x))
        return (heading + 360) % 360

def main(args=None):
    rclpy.init(args=args)
    node = WaypointNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
