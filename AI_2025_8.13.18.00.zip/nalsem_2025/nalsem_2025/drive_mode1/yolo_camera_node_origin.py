#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import cv2
from ultralytics import YOLO
from pathlib import Path
from sensor_msgs.msg import Image
from std_msgs.msg import Int32
from cv_bridge import CvBridge
import os

class YoloCameraNode(Node):
    def __init__(self):
        super().__init__('yolo_camera_node')

        # 1️⃣ 모델 경로 확인
        model_path = Path.home() / "Downloads" / "best.pt"
        if not model_path.exists():
            self.get_logger().error(f"모델 파일을 찾을 수 없습니다: {model_path}")
            raise FileNotFoundError(f"Model file not found: {model_path}")

        self.model = YOLO(str(model_path))
        self.bridge = CvBridge()

        # 2️⃣ 퍼블리셔 선언
        self.image_pub = self.create_publisher(Image, '/yolo/image_raw', 10)
        self.heading_pub = self.create_publisher(Int32, '/camera_heading', 10)

        # 3️⃣ 카메라 포트 확인
        camera_path = "/dev/camera"
        if not os.path.exists(camera_path):
            self.get_logger().error(f"카메라 포트가 존재하지 않습니다: {camera_path}")
            raise FileNotFoundError(f"Camera port not found: {camera_path}")

        self.cap = cv2.VideoCapture(camera_path)
        if not self.cap.isOpened():
            self.get_logger().error(f"카메라 연결 실패: {camera_path}")
            raise RuntimeError(f"카메라를 열 수 없습니다: {camera_path}")

        self.get_logger().info(f"✅ YOLO 카메라 노드 시작됨 (포트: {camera_path})")

        width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.get_logger().info(f"📷 프레임 해상도: {width}x{height}")

        self.timer = self.create_timer(0.1, self.capture_and_detect)

    def remap_x(self, cx):
        """카메라 X축(0~640)을 125~55로 반전 매핑"""
        x_norm = cx / 640.0
        return round(125 - 70 * x_norm)  # 🔁 좌우 반전

    def capture_and_detect(self):
        ret, frame = self.cap.read()
        if not ret or frame is None:
            self.get_logger().warn("프레임을 읽을 수 없습니다.")
            return

        try:
            results = self.model.predict(source=frame, verbose=False, conf=0.3)[0]
        except Exception as e:
            self.get_logger().error(f"YOLO 예측 중 오류 발생: {e}")
            return

        for box in results.boxes:
            cls_id = int(box.cls[0])
            label = self.model.names.get(cls_id, 'Unknown')
            conf = float(box.conf[0])

            if conf < 0.6:
                continue  # ✅ 정확도 60% 미만은 무시

            xyxy = box.xyxy[0].tolist()
            x1, y1, x2, y2 = map(int, xyxy)
            cx = (x1 + x2) // 2

            mapped_x = self.remap_x(cx)
            self.get_logger().info(
                f"🎯 감지: {label} ({conf:.2f}) | 변환된 X좌표: {mapped_x} | 원본 중심: {cx}"
            )

            msg = Int32()
            msg.data = mapped_x
            self.heading_pub.publish(msg)

        annotated = results.plot()
        img_msg = self.bridge.cv2_to_imgmsg(annotated, encoding="bgr8")
        self.image_pub.publish(img_msg)

    def destroy_node(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()
        self.get_logger().info("🛑 YOLO 카메라 노드 종료")
        super().destroy_node()

def main(args=None):
    try:
        rclpy.init(args=args)
        node = YoloCameraNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"[예외 발생] {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
