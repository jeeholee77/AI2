import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray
import serial
import time
import os

class MotorOperator(Node):
    def __init__(self):
        super().__init__('motor_operator')
        self.get_logger().info('Motor operator node started.')

        # 위치 교환: 실제 왼쪽 ↔ 오른쪽 물리 연결 반영
        left_port = '/dev/left_motor'
        right_port = '/dev/right_motor'

        try:
            # 포트 존재 확인
            if not os.path.exists(left_port):
                raise FileNotFoundError(f"{left_port} 가 존재하지 않습니다.")
            if not os.path.exists(right_port):
                raise FileNotFoundError(f"{right_port} 가 존재하지 않습니다.")

            # 시리얼 연결
            self.ser1 = serial.Serial(left_port, 9600, timeout=1)
            self.ser2 = serial.Serial(right_port, 9600, timeout=1)
            time.sleep(2)
            self.get_logger().info(f'Serial ports connected: {left_port}, {right_port}')
        except (serial.SerialException, FileNotFoundError) as e:
            self.get_logger().error(f'Serial connection error: {e}')
            self.ser1 = None
            self.ser2 = None

        # 토픽 구독
        self.subscription = self.create_subscription(
            Int32MultiArray,
            '/motor_cmd',
            self.cmd_callback,
            10
        )

    def cmd_callback(self, msg):
        if len(msg.data) != 2:
            self.get_logger().warn("motor_cmd 데이터는 [left, right] 두 개여야 합니다.")
            return

        left_pwm, right_pwm = msg.data
        self.set_pwm(left_pwm, right_pwm)
        self.get_logger().info(f"토픽으로 받은 PWM: {left_pwm} / {right_pwm}")

    def set_pwm(self, left, right):
        if self.ser1 and self.ser2:
            if 1100 <= left <= 1900 and 1100 <= right <= 1900:
                self.ser1.write(f"{left}\n".encode())
                self.ser2.write(f"{right}\n".encode())
            else:
                self.get_logger().warn("PWM 값 범위 초과")
        else:
            self.get_logger().warn("시리얼 포트가 초기화되지 않음")

    def close_ports(self):
        if self.ser1:
            self.ser1.close()
        if self.ser2:
            self.ser2.close()
        self.get_logger().info("Serial ports closed.")

def main(args=None):
    rclpy.init(args=args)
    node = MotorOperator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.close_ports()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
