import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import Point
from collections import deque

class GpsAveragingNode(Node):
    def __init__(self):
        super().__init__('gps_averaging_node')

        self.gps_buffer = deque(maxlen=20)

        self.create_subscription(NavSatFix, '/fix', self.gps_callback, 10)

        self.corrected_pub = self.create_publisher(NavSatFix, '/gps/corrected', 10)
        self.get_logger().info('📡 GPS 평균 보정 노드 시작됨 — 수신 중...')

    def gps_callback(self, msg: NavSatFix):
        self.gps_buffer.append((msg.latitude, msg.longitude))

        self.get_logger().info(f"📍 수신 위치: 위도={msg.latitude:.7f}, 경도={msg.longitude:.7f} | {len(self.gps_buffer)}/20")

        if len(self.gps_buffer) == self.gps_buffer.maxlen:
            lat_avg, lon_avg = self.compute_average()

            # 평균 위치를 NavSatFix로 퍼블리시
            corrected = NavSatFix()
            corrected.latitude = lat_avg
            corrected.longitude = lon_avg
            corrected.altitude = msg.altitude
            corrected.header.stamp = self.get_clock().now().to_msg()
            corrected.header.frame_id = "gps"

            self.corrected_pub.publish(corrected)

            # 📢 평균 보정 위치 로그 출력
            self.get_logger().info(
                f'✅ 보정된 GPS 평균 위치: 위도={lat_avg:.7f}, 경도={lon_avg:.7f}'
            )

    def compute_average(self):
        lat_sum = sum(pt[0] for pt in self.gps_buffer)
        lon_sum = sum(pt[1] for pt in self.gps_buffer)
        return lat_sum / len(self.gps_buffer), lon_sum / len(self.gps_buffer)

def main(args=None):
    rclpy.init(args=args)
    node = GpsAveragingNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
